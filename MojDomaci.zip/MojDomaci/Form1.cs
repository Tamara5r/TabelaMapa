﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace MojDomaci
{
    public partial class Form1 : Form
    {
        public int red = 0;
        public Form1()
        {
            InitializeComponent();
        }
        public string cons = "Data Source=hp261020;Initial Catalog=tamarap2021;Integrated Security=True";
       public DataTable dt = new DataTable();
        private void button1_Click(object sender, EventArgs e)
        {
        
            SqlConnection con = new SqlConnection(cons);
            con.Open();
                string x = "insert into mapa values('" + textBox1.Text.ToString() + "','" + textBox2.Text.ToString() + "','" + textBox3.Text.ToString() + "','" + textBox4.Text.ToString() + "','" + textBox5.Text.ToString() + "')";
                SqlCommand com = new SqlCommand(x, con);
                com.ExecuteNonQuery();
            con.Close();
            dt.Clear();
            SqlDataAdapter da1 = new SqlDataAdapter("select * from mapa", con);
            da1.Fill(dt);
            osvezi(red);
        }


        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cons);
            SqlCommand com = new SqlCommand("delete from mapa where id="+textBox1.Text+"",con);
            con.Open();
            com.ExecuteNonQuery();
            con.Close();
            dt.Clear();
            SqlDataAdapter da = new SqlDataAdapter("select * from mapa",con);
            da.Fill(dt);
            red = 0;
            osvezi(red);
           

        }
        public void osvezi(int red)
        {
            textBox1.Text = dt.Rows[red]["id"].ToString();
            textBox2.Text = dt.Rows[red]["Objekat_naziv"].ToString();
            textBox3.Text = dt.Rows[red]["Geografska_sirina"].ToString();
            textBox4.Text = dt.Rows[red]["Geografska_duzina"].ToString();
            textBox5.Text = dt.Rows[red]["Nadmorska_visina"].ToString();
            button4.Enabled = (red != 0);
            button5.Enabled = (red != 0);
            button3.Enabled =(red != dt.Rows.Count - 1) ;
            button6.Enabled = (red != dt.Rows.Count - 1);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            SqlConnection con = new SqlConnection(cons);
            SqlDataAdapter da = new SqlDataAdapter("select * from mapa",con);
            da.Fill(dt);
           
            osvezi(red);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (red >= 0)
            {
                red = red - 1;
            }

            osvezi(red);
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (red <= dt.Rows.Count)
            {
                red = red + 1;
            }

            osvezi(red);
        }

        private void button5_Click(object sender, EventArgs e)
        {   red = 0;
            osvezi(red);
            
        }

        private void button6_Click(object sender, EventArgs e)
        {   red = dt.Rows.Count - 1;
            osvezi(red);
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cons);
            string id = textBox1.Text;
            string objekat= textBox2.Text;
            string geosirina = textBox3.Text;
            string geoduzina = textBox4.Text;
            string nadvisina = textBox5.Text;
            con.Open();
            SqlCommand da = new SqlCommand("update mapa set Objekat_naziv='"+objekat+ "',geografska_sirina=" + geosirina + ",geografska_duzina=" +geoduzina+ ",nadmorska_visina=" +nadvisina+ " where id = " +id+ "; ", con);
            da.ExecuteNonQuery();
            con.Close();
            dt.Clear();
            SqlDataAdapter da1 = new SqlDataAdapter("select * from mapa",con);
            da1.Fill(dt);
            osvezi(red);
        }
    }
}
